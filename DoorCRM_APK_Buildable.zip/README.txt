DoorCRM Android v2.0
Funksiyalar:
- Yangi buyurtma
- Mijoz, telefon, o‘lcham, model, rang, sana, izoh
- Soni, jami narx, avans va avtomatik qarz
- Ishlab chiqarish statuslari
- Mijozlar
- Moliyaviy hisobot
- Telefon uchun portrait Android ilova

APK build:
Android Studio -> Open -> ushbu papkani tanlang -> Build > Build APK(s).
