package uz.doorcrm;

import android.app.*; import android.os.*; import android.graphics.Color; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout content; ArrayList<Order> orders=new ArrayList<>(); int blue=Color.rgb(18,59,103);
 static class Order {String name,phone,size,model,color,date,note,status; int qty; double price,paid;
 Order(String n,String p,String s,String m,String c,String d,String no,int q,double pr,double pa){name=n;phone=p;size=s;model=m;color=c;date=d;note=no;qty=q;price=pr;paid=pa;status="Qabul qilingan";}}
 public void onCreate(Bundle b){super.onCreate(b); home();}
 TextView t(String s,int z){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(blue);x.setPadding(16,16,16,16);return x;}
 Button b(String s){Button x=new Button(this);x.setText(s);return x;}
 EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setPadding(16,8,16,8);return x;}
 void base(){LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);
 TextView h=t("🚪  DoorCRM\nEshik ishlab chiqarish CRM",20);h.setTextColor(Color.WHITE);h.setBackgroundColor(blue);all.addView(h);
 ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(12,12,12,90);sc.addView(content);all.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
 LinearLayout nav=new LinearLayout(this); String[] ns={"🏠 Bosh","📋 Buyurtma","🏭 Ishlab","👥 Mijoz","💰 Hisobot"}; for(String n:ns){Button x=b(n);nav.addView(x,new LinearLayout.LayoutParams(0,60,1)); if(n.startsWith("🏠"))x.setOnClickListener(v->home()); else if(n.startsWith("📋"))x.setOnClickListener(v->orders()); else if(n.startsWith("🏭"))x.setOnClickListener(v->production()); else if(n.startsWith("👥"))x.setOnClickListener(v->customers()); else x.setOnClickListener(v->finance());} all.addView(nav);setContentView(all);}
 void home(){base();content.addView(t("Assalomu alaykum!",25));content.addView(t("Eshik ishlab chiqarishni bitta telefondan boshqaring.",15));
 content.addView(t("📋  Buyurtmalar: "+orders.size()+"\n🏭  Jarayonda: "+active()+"\n💰  Jami savdo: "+money(sales()),18));
 Button x=b("＋ YANGI BUYURTMA");x.setOnClickListener(v->newOrder());content.addView(x);content.addView(t("\nAsosiy bo‘limlar",19));
 for(String s:new String[]{"📋 Buyurtmalar","🏭 Ishlab chiqarish","📦 Ombor","👥 Mijozlar","💰 Hisobot","👷 Ishchilar"}){Button q=b(s);content.addView(q);if(s.startsWith("📋"))q.setOnClickListener(v->orders());else if(s.startsWith("🏭"))q.setOnClickListener(v->production());else if(s.startsWith("👥"))q.setOnClickListener(v->customers());else if(s.startsWith("💰"))q.setOnClickListener(v->finance());}}
 void orders(){base();content.addView(t("📋 Buyurtmalar",25));Button x=b("＋ Yangi buyurtma");x.setOnClickListener(v->newOrder());content.addView(x);if(orders.isEmpty())content.addView(t("Hozircha buyurtma yo‘q.",17));for(Order o:orders){content.addView(card(o));}}
 TextView card(Order o){TextView x=t("🚪 "+o.name+"  |  "+o.status+"\n📞 "+o.phone+"\n"+o.qty+" dona · "+o.size+" · "+o.model+" · "+o.color+"\n💰 "+money(o.price)+"   Avans: "+money(o.paid)+"   Qarz: "+money(o.price-o.paid)+"\n📅 "+(o.date.length()==0?"Sana yo‘q":o.date),15);x.setBackgroundColor(Color.WHITE);x.setPadding(18,18,18,18);return x;}
 void newOrder(){base();content.addView(t("＋ Yangi buyurtma",25));EditText n=e("Mijoz ismi"),p=e("Telefon"),sz=e("O‘lcham: 800×2100"),m=e("Model: Klassik"),c=e("Rang: Oq"),d=e("Tayyor sana: 2026-09-30"),no=e("Izoh");EditText q=e("Soni: 1"),pr=e("Jami narx (so‘m)"),pa=e("Avans (so‘m)");
 for(EditText z:new EditText[]{n,p,sz,m,c,q,pr,pa,d,no})content.addView(z);
 Button save=b("💾 BUYURTMANI SAQLASH");content.addView(save);save.setOnClickListener(v->{try{int qi=Integer.parseInt(q.getText().toString());double price=Double.parseDouble(pr.getText().toString()),paid=Double.parseDouble(pa.getText().toString());orders.add(new Order(n.getText().toString(),p.getText().toString(),sz.getText().toString(),m.getText().toString(),c.getText().toString(),d.getText().toString(),no.getText().toString(),qi,price,paid));orders();}catch(Exception ex){Toast.makeText(this,"Soni, narx va avansni to‘g‘ri kiriting",Toast.LENGTH_SHORT).show();}});}
 void production(){base();content.addView(t("🏭 Ishlab chiqarish",25));String[] st={"Qabul qilingan","Ishlab chiqarishda","Tayyor","O‘rnatilgan"};for(Order o:orders){Button x=b(o.name+" — "+o.status+"\n"+o.qty+" dona");x.setOnClickListener(v->{int i=Arrays.asList(st).indexOf(o.status);o.status=st[(i+1)%st.length];production();});content.addView(x);}}
 void customers(){base();content.addView(t("👥 Mijozlar",25));HashSet<String> s=new HashSet<>();for(Order o:orders)s.add(o.name+" — "+o.phone);for(String x:s)content.addView(t(x,16));if(s.isEmpty())content.addView(t("Mijozlar yo‘q.",16));}
 void finance(){base();double sales=sales(),paid=0;for(Order o:orders)paid+=o.paid;content.addView(t("💰 Hisobot",25));content.addView(t("Jami savdo: "+money(sales)+"\nJami avans: "+money(paid)+"\nJami qarz: "+money(sales-paid),18));}
 double sales(){double s=0;for(Order o:orders)s+=o.price;return s;}int active(){int n=0;for(Order o:orders)if(o.status.equals("Ishlab chiqarishda"))n++;return n;}String money(double n){return String.format(Locale.US,"%,.0f so‘m",n);}
}