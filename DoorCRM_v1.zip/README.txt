DoorCRM v1 — telefon uchun ishlaydigan demo/prototip.
Ishlatish: index.html faylini Chrome orqali oching. Ma'lumotlar shu qurilmada localStorage orqali saqlanadi.
Asosiy funksiyalar: buyurtma qo‘shish, qidirish, statusni o‘zgartirish, mijozlar, ishlab chiqarish, moliyaviy hisob.
